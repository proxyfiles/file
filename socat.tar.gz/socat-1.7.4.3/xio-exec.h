/* source: xio-exec.h */
/* Copyright Gerhard Rieger and contributors (see file CHANGES) */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_exec_h_included
#define __xio_exec_h_included 1

extern const struct addrdesc addr_exec;

extern const struct optdesc opt_dash;

#endif /* !defined(__xio_exec_h_included) */
